$(window).on("load", () => {
  $(".loading").fadeOut("slow");
});
