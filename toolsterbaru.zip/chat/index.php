<?php


session_start();

//Create a session of username and logging in the user to the chat room
if(isset($_POST['username'])){
	$_SESSION['username']=$_POST['username'];
}

//Unset session and logging out user from the chat room
if(isset($_GET['logout'])){
	unset($_SESSION['username']);
	header('Location:index.php');
}

?>
<html>
<head>
	<title>Ngobrol Sans</title>
	
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Caveat+Brush&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<script type="text/javascript" src="js/jquery-1.10.2.min.js" ></script>
  <script type="text/javascript" src="js/pubnub-3.7.13.min.js" ></script>
</head>

<style>
 * { 

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }
        h4 {
        	font-family: 'Caveat Brush', cursive;
        }
        h2 {
        	font-family: 'Caveat Brush', cursive;
            color:#696969;
        }



        html {

            position: relative;
            min-height: 100%;

        }

        .link {

        	text-decoration: none;
            color: white;
            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        

        .link:hover{
        	text-decoration: none;
            color: white;
            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }



        body {

            margin-bottom: 60px;

        }
        .kolomchat {
        	height: 550px;
            width: auto;
            overflow: scroll;
        }



        .footer {

            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;

        }



        .container-fluid {

            /* width: 500px; */

            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;

        }

        button {

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        .disclaimer{
    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;

        }
</style>
<nav class="navbar navbar-expand-lg navbar-light" style="background:#696969;">
<span class="navbar-brand" style="background:#696969; color:white;">

</span>

 </nav>
<center><h2><i class="fa fa-copyright" name='clear' id='clear' title="Clear Chat"  style="color:white;"></i></h2></center> 

<div class="container-fluid">
        <div class="row mt-2">
           <div class="col justify-content-center">
              	<br><center>
        <?php // Adding the logout link only for logged in users  ?>
		<?php if(isset($_SESSION['username'])) { ?>Selamat Bergabung<br>
	    <h4><i class="fa fa-user"></i>&nbsp;<?php echo $_SESSION['username'] ?></h4>

		<?php } ?>
			</center><br>
            <div class='main'>
<?php //Check if the user is logged in or not ?>
<?php if(isset($_SESSION['username'])) { ?>
	<div class="alert alert-secondary" role="alert">
<div id='result' class="kolomchat"></div>
</div>

<form method="post" onsubmit="return submitchat();">
	<input type='text' name='chat' id='chatbox' autocomplete="off" required placeholder="Ketikkan Pesan" class="form-control"/><br>
	<div class="alert alert-secondary" role="alert">
	<button type='submit' name='send' id='send' class='btn btn-secondary' /><i class="fa fa-send"></i></button>
	
</form>
	<a class="btn btn-secondary" href="?logout"><i class="fa fa-sign-out"></i></a>
	</div>


<script>
// Javascript function to submit new chat entered by user
function submitchat(){
		if($('#chat').val()=='' || $('#chatbox').val()==' ') return false;
		$.ajax({
			url:'chat.php',
			data:{chat:$('#chatbox').val(),ajaxsend:true},
			method:'post',
			success:function(data){
				$('#result').html(data); // Get the chat records and add it to result div
				$('#chatbox').val(''); //Clear chat box after successful submition

				document.getElementById('result').scrollTop=document.getElementById('result').scrollHeight; // Bring the scrollbar to bottom of the chat resultbox in case of long chatbox
			}
		})
		return false;
};

// Function to continously check the some has submitted any new chat
setInterval(function(){
	$.ajax({
			url:'chat.php',
			data:{ajaxget:true},
			method:'post',
			success:function(data){
				$('#result').html(data);
			}

	})

}
,1000);


// Function to chat history
$(document).ready(function(){
	$('#clear').click(function(){
		if(!confirm('Hapus Semua Chat ?'))
			return false;
		$.ajax({
			url:'chat.php',
			data:{username:"<?php echo $_SESSION['username'] ?>",ajaxclear:true},
			method:'post',
			success:function(data){
				$('#result').html(data);
			}
		})
	})
})
</script>
<?php } else { ?>
	<form method="post">
		<input type='text' maxlength='20' class='form-control' required placeholder="Masukkan Nama" name='username' /><br>
		<button type='submit' class='btn btn-secondary btn-block' />Mulai Chat <i class="fa fa-send"></i></button>
	</form>
<?php } ?>

</div>
<script>
  <?php
  $count = 0;
$myFile = "chatdata.txt";
$fh = fopen($myFile, 'r');
while(!feof($fh)){
    $fr = fread($fh, 8192);
    $count += substr_count($fr, 'br');
}
fclose($fh);
?>
  setInterval(function()
{
  <?php

  $count2 = 0;
$myFile = "chatdata.txt";
$fh = fopen($myFile, 'r');
while(!feof($fh)){
    $fr = fread($fh, 8192);
    $count2 += substr_count($fr, 'br');
}
fclose($fh);
  if($count2<$count) {
    ?>
    alert("under construction");
  
<?php } ?>

}, 3000);
</script>

            </div>
        </div>
        <div class="card-footer">
                        <center><small><i>Coded by GresiXploiter Team</i></small></center>
         </div>

    </div>

		
	



</html>