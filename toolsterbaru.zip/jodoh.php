<?php

function intPart($floatNum) {
    return($floatNum<-0.0000001 ? ceil($floatNum-0.0000001) : floor($floatNum+0.0000001));
}

function hdate($day,$month,$year) {
    $julian = GregorianToJD($month, $day, $year);
    if ($julian >= 1937808 && $julian <= 536838867) {
        $date = cal_from_jd($julian, CAL_GREGORIAN);
        $d = $date['day'];
        $m = $date['month'] - 1;
        $y = $date['year'];
    
        $mPart = ($m-13)/12;
        $jd = intPart((1461*($y+4800+intPart($mPart)))/4)+
        intPart((367*($m-1-12*(intPart($mPart))))/12)-
        intPart((3*(intPart(($y+4900+intPart($mPart))/100)))/4)+$d-32075;
    
        $l = $jd-1948440+10632;
        $n = intPart(($l-1)/10631);
        $l = $l-10631*$n+354;
        $j = (intPart((10985-$l)/5316))*(intPart((50*$l)/17719))+(intPart($l/5670))*(intPart((43*$l)/15238));
        $l = $l-(intPart((30-$j)/15))*(intPart((17719*$j)/50))-(intPart($j/16))*(intPart((15238*$j)/43))+29;
    
        $m = intPart((24*$l)/709);
        $d = $l-intPart((709*$m)/24);
        $y = 30*$n+$j-30;
        $yj = $y+512;
        $h = ($julian+3)%5;

        if($julian<=1948439) $y–;
    
        return array(
            'day' => $date['day'],
            'month' => $date['month'],
            'year' => $date['year'],
            'dow' => $date['dow'],
            'hijriday' => $d,
            'hijrimonth' => $m, 
            'hijriyear' => $y,
            'javayear' => $yj,
            'javadow' => $h
        );
    } else {
        return false;
    }
}

$imonth = Array(
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
);

$amonth = Array(
    'Muharram',
    'Safar',
    'Rabi\'ul Awal',
    'Rabi\'ul Akhir',
    'Jumadil Awal',
    'Jumadil Akhir',
    'Rajab',
    'Sya\'ban',
    'Ramadhan',
    'Syawal',
    'Dzul Qa\'dah',
    'Dzul Hijjah'
);

$jmonth = Array(
    'Suro',
    'Sapar',
    'Mulud',
    'Ba\'da Mulud',
    'Jumadil Awal',
    'Jumadil Akhir',
    'Rejeb',
    'Ruwah',
    'Poso',
    'Syawal',
    'Dulkaidah',
    'Besar'
);

$aday = Array(
    'Al-Ahad',
    'Al-Itsnayna',
    'Ats-Tsalatsa',
    "Al-Arba'a",
    "Al-Hamis",
    "Al-Jum'a",
    "As-Sabt"
);

$iday = Array(
    'Minggu',
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu'
);

$jday = Array(
    'Pon',
    'Wage',
    'Kliwon',
    'Legi',
    'Pahing'
);

if (isset($_POST['submit'])) {
    
    $date1 = explode("-", $_POST['date1']);
    $date2 = explode("-", $_POST['date2']);

    $date1 = hdate($date1[2], $date1[1], $date1[0]);
    $date2 = hdate($date2[2], $date2[1], $date2[0]);

    $p1['hari'] = $iday[$date1['dow']];
    $p1['pasaran'] = $jday[$date1['javadow']];
    $p2['hari'] = $iday[$date2['dow']];
    $p2['pasaran'] = $jday[$date2['javadow']];

    $hari = [
        'Minggu' => 5,
        'Senin' => 4,
        'Selasa' => 3,
        'Rabu' => 7,
        'Kamis' => 8,
        'Jumat' => 6,
        'Sabtu' => 9
    ];

    $neptu = [
        'Legi' => 5,
        'Pahing' => 9,
        'Pon' => 7,
        'Wage' => 4,
        'Kliwon' => 8,
    ];

    foreach ($hari as $key => $value) {
        if ($p1['hari'] == $key) {
            $p1['hari_val'] = $value;
            break;
        }
    }

    foreach ($neptu as $key => $value) {
        if ($p1['pasaran'] == $key) {
            $p1['pasaran_val'] = $value;
            break;
        }
    }

    foreach ($hari as $key => $value) {
        if ($p2['hari'] == $key) {
            $p2['hari_val'] = $value;
            break;
        }
    }

    foreach ($neptu as $key => $value) {
        if ($p2['pasaran'] == $key) {
            $p2['pasaran_val'] = $value;
            break;
        }
    }

    $jumlahWeton = [
        1 => 'Pegat',
        2 => 'Ratu',
        3 => 'Jodoh',
        4 => 'Topo',
        5 => 'Tinari',
        6 => 'Padu',
        7 => 'Sujanan',
        8 => 'Pesthi',
        9 => 'Pegat'
    ];

    $i = 1;
    $c = 1;

    $weton = "";

    while ($i <= 36) {
        if (in_array($i, array(10, 19, 28)) and $i <= 36) {
            $c = 1;
        }
        if ($p1['hari_val']+$p1['pasaran_val']+$p2['hari_val']+$p2['pasaran_val'] == $i) {
            $weton = $jumlahWeton[$c];
            break;
        } else {
            $i++;
            $c++;
        }
    }

}

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">

    <title>Weton Jodoh by why.id</title>
    <!-- CODED BY WHY.ID DENGAN IQ 200+ -->
    <style>
        * { 
            font-family: 'Quicksand', sans-serif;
            font-size: 15px;
        }

        html {
            position: relative;
            min-height: 100%;
        }

        body {
            margin-bottom: 60px;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;
        }

        .container-fluid {
            /* width: 500px; */
            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;
        }
        .disclaimer{
    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light"style="background:#696969; color:white;">
        <span class="navbar-brand"style="background:#696969; color:white;"></span>
    </nav>
    <br><br>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col justify-content-center">

                <?php if(isset($_POST['submit']) and !empty(isset(($weton)))){ ?>
                    <?php

                    switch ($weton) {
                        case 'Pegat':
                            $x = "Pegat / Pegatan";
                            $y = "Pegat berarti cerai atau berpisah. Jika neptu calon pengantin berjumlah 1, 9, 17, 25, ataupun 33, maka kemungkinan besar pasangan tersebut akan pisah di tengah jalan. Rumah tangga pada neptu ini biasanya akan dirundung masalah. ";
                            $z = "alert-danger";
                            break;
                        case 'Ratu':
                            $x = "Ratu";
                            $y = "Identik dengan sosok yang dihormati. Sesuai dengan namanya, Ratu berati pasangan ini akan hidup bagaikan seorang ratu dengan banyak harta dan hidup harmonis. Dewi fortuna akan selalu bersama pasangan ini. Neptu untuk Ratu adalah 2, 10, 18, 26, dan 34.";
                            $z = "alert-success";
                            break;
                        case 'Jodoh':
                            $x = "Jodoh";
                            $y = "Jodoh artinya pasangan ini dipercaya akan memiliki rumah tangga yang harmonis hingga Tuhan memisahkan. 3, 11, 19, 27, dan 35 adalah neptu impian dalam hitungan Jawa karena neptu tersebut berarti Jodoh. Nasib rumah tangga dapat harmonis sampai tua.";
                            $z = "alert-success";
                            break;
                        case 'Topo':
                            $x = "Topo";
                            $y = "Dalam bahasa jawa bisa diartikan bertirakat. Topo adalah gambaran hidup manusia seutuhnya. Tafsir ini mengatakan bahwa pasangan akan memiliki banyak masalah di awal pernikahan. Akan tetapi, seiring berjalannya waktu, semuanya akan membaik selama pasangan tersebut bisa bertahan. Neptu untuk Topo adalah 4, 12, 20, 28, dan 36. Tapi setelah mempunyai anak dan cukup lama berumah tangga, hidupnya akan sukses serta bahagia.";
                            $z = "alert-warning";
                            break;
                        case 'Tinari':
                            $x = "Tinari";
                            $y = "Pasangan dengan neptu Tinari biasanya akan hidup bahagia dengan kondisi keuangan yang berkecukupan. Neptu untuk tafsir Tinari adalah 5, 13, 21, dan 29. Banyak yang beranggapan bahwa Tinari lebih baik dari Jodoh karena Tinari juga menggambarkan kemapanan finansial. Pasangan ini akan mendapatkan kebahagiaan. Kemudahan dalam mencari rezeki dan tidak akan hidup berkekurangan. Hidupnya akan diliputi keberuntungan.";
                            $z = "alert-success";
                            break;
                        case 'Padu':
                            $x = "Padu";
                            $y = "Padu artinya pertengkaran. Berdasarkan hitungan Jawa, pasangan dengan neptu padu akan sering bertengkar. Padu memiliki neptu 6, 14, 22, dan 30. Meski sering terjadi pertengkaran, nasib rumah tangga tidak sampai bercerai. Pertengkaran ini bahkan dipicu dari hal-hal yang bersifat sepele.";
                            $z = "alert-danger";
                            break;
                        case 'Sujanan':
                            $x = "Sujanan";
                            $y = "Sujanan memiliki makna yang mirip dengan Padu. Akan tetapi, pasangan dengan tafsir Sujanan biasanya akan menghadapi masalah dengan perselingkuhan. Neptu untuk Sujanan adalah 7, 15, 23, dan 31.";
                            $z = "alert-danger";
                            break;
                        case 'Pesthi':
                            $x = "Pesthi";
                            $y = "Pesthi yaitu keluarga yang Sakinah, Mawadah, dan Warohmah. Bagi masyarakat Jawa yang tergolong agamis, hitungan Jawa ini adalah yang terbaik karena kebahagiaan pasangan bukan Cuma di dunia, tetapi juga di akhirat. Neptu untuk Pesthi adalah 8, 16, 254, dan 32.";
                            $z = "alert-success";
                            break;
                    }

                    ?>
                    	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert <?php echo $z ?> alert-dismissible fade show" role="alert">
                    <strong><?php echo $x ?></strong>. <?php echo $y ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php } else { ?>
                	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div>
                <?php } ?>

                <div class="card">
                    <div class="card-body"style="background:#DCDCDC;">
                        <form action="" method="post" autocomplete="off">
                            <div class="form-group">
                                <label><i class="fa fa-plus-circle"></i> Kelahiranmu</label>
                                <input type="date" name="date1" class="form-control" required>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label><i class="fa fa-minus-circle"></i> Kelahiran Jodohmu</label>
                                <input type="date" name="date2" class="form-control" required>
                            </div>
                            <hr>
                            <button type="submit" name="submit" class="btn btn-dark btn-block"><i class="fa fa-check-square"></i> Lihat hasil </button>
                        </form>
                    </div>
                    <div class="card-footer">
                        <small><i>Sumber : Primbon Jawa Kuno </i></small>
                    </div>
                </div>
            </div>
        </div>
        
    </div>

    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>