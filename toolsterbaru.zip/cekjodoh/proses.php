

<?php
    
    $img = $_POST['image'];
    $folderPath = "upload/";
  
    $image_parts = explode(";base64,", $img);
    $image_type_aux = explode("image/", $image_parts[0]);
    $image_type = $image_type_aux[1];
  
    $image_base64 = base64_decode($image_parts[1]);
    $fileName = uniqid() . '.png';
  
    $file = $folderPath . $fileName;
    file_put_contents($file, $image_base64);
  
    
  
?>

<html lang="en">

<head>
    <!-- Required meta tags -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
    <!-- Webcam Harus Terbaru -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Preview HTML Code</title>
    <!-- CODED BY WHY.ID DENGAN IQ 200+ -->
    <style>

        * { 

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        html {

            position: relative;
            min-height: 100%;

        }
        
        .link {
        	text-decoration: none;
            color: white;
        }
        
        .link:hover{
        	text-decoration: none;
            color: white;
        }


        body {
            margin-bottom: 60px;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;

        }

        .container-fluid {

            /* width: 500px; */

            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;

        }

        button {

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        .disclaimer{

    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;

        }

    </style>

</head>

<body>
<script>
		swal("Berhasil", "Silahkan tunggu sebentar !", "success");
</script>
    <nav class="navbar navbar-expand-lg navbar-light" style="background:#696969;">

        <span class="navbar-brand" style="background:#696969; color:white;"></span>

    </nav>

<br><br>
<div class="container-fluid">
        <div class="row mt-2">
            <div class="col justify-content-center">
                    	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div><br>
                <button type="submit" name="submit" class="btn btn-dark btn-block"><a class="link" href="index.php"> Kembali </button></a>
            <div class="col-md-6">
            </div>
                </form>
            </div>
        </div>

        <div class="card-footer">

                        <center><small><i>Tools akan di-update setiap bulan</i></small></center>

         </div>
 </div>
</body>
</html>
