

<html lang="en">

<head>
    <!-- Required meta tags -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
    <!-- Webcam Harus Terbaru -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Cek Jodohmu</title>
    <!-- CODED BY WHY.ID DENGAN IQ 200+ -->
    <style>

        * { 

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        html {

            position: relative;
            min-height: 100%;

        }


        body {
            margin-bottom: 60px;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;

        }

        .container-fluid {

            /* width: 500px; */

            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;

        }

        button {

            font-family: 'Quicksand', sans-serif;
            font-size: 15px;

        }

        .disclaimer{

    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;

        }

    </style>

</head>

<body>
<script>
		swal("Perhatian", "Izinkan akses kamera !", "warning");
</script>
    <nav class="navbar navbar-expand-lg navbar-light" style="background:#696969;">

        <span class="navbar-brand" style="background:#696969; color:white;"></span>

    </nav>

<br><br>
<div class="container-fluid">
        <div class="row mt-2">
            <div class="col justify-content-center">
                    	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div>
                <form method="POST" action="proses.php">
            <div class="col-md-6">
            	<center>
                <div id="my_camera" hidden></div>
                </center>
                <br/>
                
                <input type="hidden" name="image" class="image-tag">
            </div>
            <div class="col-md-6">
                <div id="results" hidden></div>
            </div>
            <div class="col-md-12 text-center">
                <br/>
                <button class="btn btn-dark btn-block" onClick="take_snapshot()">Lihat Jodoh</button>
            </div>
                </form>
            </div>
        </div>

        <div class="card-footer">

                        <center><small><i>Tools akan di-update setiap bulan</i></small></center>

         </div>
 </div>
 <script language="JavaScript"> 
    Webcam.set({
        width: 490,
        height: 390,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
  
    Webcam.attach( '#my_camera' );
  
    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
        } );
    }
</script>
</body>
</html>
