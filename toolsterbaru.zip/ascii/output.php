<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Konversi Gambar Ke ASCII</title>
        <link href="https://fonts.googleapis.com/css?family=Special+Elite" rel="stylesheet">
        <link rel="stylesheet" href="./output.css">
    </head>
    <style>
        .disclaimer{

    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;
        }
    </style>
    <body>
        <?php
            
            include './image-to-ascii.php';
         ?>
    </body>
</html>
