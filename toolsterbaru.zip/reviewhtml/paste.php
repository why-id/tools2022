<?php
$fname= "./whyid/whyid".date("ydhisms").'.html'; // Nama File
$myfile = fopen($fname, "w") or die("Terjadi Error !");
$txt = $_POST["xcode"];
fwrite($myfile, $txt);
fclose($myfile);
$files = glob("./whyid/"."*"); // Folder
$now   = time();

foreach ($files as $file) {
  if (is_file($file)) {
    if ($now - filectime($file) >= 240) { // Waktu Hapus File 1Jam >> 3600 Detik
        if ($file != './index.html') {
          unlink ($file);
        }
    }
  }
}

Header("Location: $fname");
?>