<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">

    <title>QR GENERATOR</title>
   </head>
<style>
 * { 

            font-family: 'Quicksand', sans-serif;

            font-size: 15px;

        }



        html {

            position: relative;

            min-height: 100%;

        }

        .link {

        	text-decoration: none;

            color: white;

            font-family: 'Quicksand', sans-serif;

            font-size: 15px;

        }

        

        .link:hover{

        	text-decoration: none;

            color: white;

            font-family: 'Quicksand', sans-serif;

            font-size: 15px;

        }



        body {

            margin-bottom: 60px;

        }



        .footer {

            position: absolute;

            bottom: 0;

            width: 100%;

            height: 60px;

            line-height: 60px;

            background-color: #f5f5f5;

            text-align: center;

        }



        .container-fluid {

            /* width: 500px; */

            width: auto;

            max-width: 680px;

            padding: 0 15px;

            border:4px solid #696969;

            border-radius:3px;

        }

        button {

            font-family: 'Quicksand', sans-serif;

            font-size: 15px;

        }

        .disclaimer{

    	opacity: 0 !important;

    	pointer-events:none !important;

     	width: 0px !important;

    	height: 0px !important;

     	visibility:hidden !important;

     	display:none !important;

        }
</style>
 <nav class="navbar navbar-expand-lg navbar-light" style="background:#696969;">

        <span class="navbar-brand" style="background:#696969; color:white;"></span>

    </nav>

    <br><br>


<div class="container-fluid">

        <div class="row mt-2">

            <div class="col justify-content-center">

                    	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>

                <div class="alert alert-secondary" role="alert">

                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>

                    </button>

                </div>

            </div>

        </div>
<?php    
    
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    
    $filename = $PNG_TEMP_DIR.'test.png';
    
    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'L';
    if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
        $errorCorrectionLevel = $_REQUEST['level'];    

    $matrixPointSize = 4;
    if (isset($_REQUEST['size']))
        $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);


    if (isset($_REQUEST['data'])) { 
    
        //it's very important!
        if (trim($_REQUEST['data']) == '')
            die('data cannot be empty! <a href="?">back</a>');
            
        // user data
        $filename = $PNG_TEMP_DIR.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
        QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
        
    } else {    
    
        //default data
        echo '<br>';
        
    }    
        
    //display generated file
    echo '<center><img src="'.$PNG_WEB_DIR.basename($filename).'" /><hr/></center>';  
    
    //config form
    echo '<form action="index.php" method="post" class="form-control">&nbsp;
         <input name="data" maxlength="50" class="form-control" placeholder="Masukkan Teksnya"  />&nbsp;
         <select name="level" class="form-control" hidden>
            <option value="M"'.(($errorCorrectionLevel=='M')?' selected':'').'>M</option>
        </select>&nbsp;
        <select name="size" class="form-control">';
        
    for($i=1;$i<=10;$i++)
        echo '<option class="form-control" value="'.$i.'"'.(($matrixPointSize==$i)?' selected':'').'>'.$i.'</option>';
        
    echo '</select>&nbsp;
        <input type="reset" class="btn btn-secondary btn-block" value="RESET">&nbsp;
        <input type="submit" class="btn btn-secondary btn-block" value="BUAT QR"></form><hr/>';
        
     
?>

        <div class="card-footer">

                        <center><small><i>Tools akan di-update setiap bulan</i></small></center>

         </div>

    </div>

</html>

    