<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Font GoogleApis -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">

    <title>Hitung umur by why.id</title>
    <!-- CODED BY WHY.ID DENGAN IQ 200+ -->
    <style>
        * { 
            font-family: 'Quicksand', sans-serif;
            font-size: 15px;
        }

        html {
            position: relative;
            min-height: 100%;
        }

        body {
            margin-bottom: 60px;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;
        }

        .container-fluid {
            /* width: 500px; */
            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;
        }
        .disclaimer{
    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light"style="background:#696969; color:white;">
        <span class="navbar-brand"style="background:#696969; color:white;"></span>
    </nav>
    <br><br>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col justify-content-center">

                <?php 
                // Process Data
                if(isset($_POST['submit'])){
                    $lahir = new DateTime($_POST['tanggal_lahir']);
                    $today = new DateTime($_POST['tanggal_today']);
                    $res = date_diff($lahir, $today);
                 ?>
                    	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div>
                <?php } else { ?>
                	<br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div>
                <?php } ?>

                <div class="card">
                    <div class="card-body"style="background:#DCDCDC;">
                        <form action="" method="POST" autocomplete="off">
                            <div class="form-group">
                                <label><i class="fa fa-plus-circle"></i> Tanggal Lahir</label>
                                <input type="date" name="tanggal_lahir" class="form-control" required>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label><i class="fa fa-minus-circle"></i> Tanggal Sekarang</label>
                                <input type="date" name="tanggal_today" class="form-control" required>
                            </div>
                            <hr>
                            <button type="submit" name="submit" class="btn btn-dark btn-block"><i class="fa fa-check-square"></i> Lihat umur </button>
                        </form>
                    </div>
                    <div class="card-footer">
                        <center><small><u>Usia Kamu</u></small></center>
                    </div>
                    <?php
                      echo"<center><div class='card-footer'><p>$res->y Tahun $res->m Bulan $res->d Hari</p></center>";
                    ?>
                </div>
            </div>
        </div>
        
    </div>

    <br><br>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
