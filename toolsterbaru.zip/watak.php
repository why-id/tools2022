<!DOCTYPE HTML>
<html>
	<head>
		<title>Watak Zodiak</title>
		<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Font GoogleApis -->
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">

	</head>
	<body>
	<style>
        * { 
            font-family: 'Quicksand', sans-serif;
            font-size: 15px;
        }

        html {
            position: relative;
            min-height: 100%;
        }

        body {
            margin-bottom: 60px;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            height: 60px;
            line-height: 60px;
            background-color: #f5f5f5;
            text-align: center;
        }

        .container-fluid {
            /* width: 500px; */
            width: auto;
            max-width: 680px;
            padding: 0 15px;
            border:4px solid #696969;
            border-radius:3px;
        }
        .disclaimer{
    	opacity: 0 !important;
    	pointer-events:none !important;
     	width: 0px !important;
    	height: 0px !important;
     	visibility:hidden !important;
     	display:none !important;
        }

    </style>
<script type="text/javascript">
//Array value
var datazodiak = [
    ["Capicorn", "Zodiak ini melambangkan kambing amaltheus ini merupakan zodiak yang sangat mengutakan kesuksesan, terutama soal pekerjaan atau karir. Sehingga, ia pun sangat ambisius dalam mencapai hal yang diinginkan, hingga ia harus mengeluarkan semua kebijaksanaan dalam bekerja, tak melepas tanggung jawab, dan keseriusan dalam belajar. Namun, dibalik kegigihannya yang merupakan sifat baik dari Capricorn, ia juga memiliki sifat yang buruk, yakni suka memandang negatif."],
    ["Aquarius", "Melambangkan gelombang air yang memiliki alur, pemilik salah satu sifat 12 zodiak lengkap yakni Aquarius ini ternyata sangat tertarik dengan dunia petualangan. Mereka pun sangat memiliki rasa ingin tahu yang tinggi, berjiwa kemanusiaan, gerak cepat, progesif, hingga mampu memberikan manfaat untuk orang yang ada disekitarnya. Akan tetapi, ternyata ada juga sifat yang membuat Aquarius menjadi seseorang yang tak mengasyikkan, yakni karena memiliki sifat buruk seperti suka membantah, pemberontak, tidak konsisten, tidak bisa diharapkan, malas berpikir. Namun, meski begitu Aquarius termasuk dalam golongan zodiak yang stabil dan memiliki ketahanan yang cukup baik."],
    ["Pisces", "Pisces merupakan zodiak yang memiliki sifat manja dan penuh dengan cinta. Mereka selelu memperlihatkan kepercayaan, kesepahaman, puitis, penyuka musik, setia, penghibur, dan pantang menyerah. Namun, Pisces ternyata juga memiliki sifat yang membuatnya menjadi merasa bingung, sering merasa bersalah, mudah kecewa, khawatir yang berlebih, risau, hingga mudah menjadi sasaran penipuan. Sifat yang kadang mudah mengalami perubahan dari kebalikan baik dan buruk, membuat Pisces masuk dalam kategori variabel, sehingga zodiak ini bisa dibilang fleksibel."],
    ["Aries", "Aries dikenal sebagai seseorang yang melambangkan keberanian. Tidak hanya itu, mereka juga memiliki keyakinan diri yang tinggi, inisiatif, mengutamakan tindakan, memiliki pertahanan diri, pejuang, dan pecinta juga. Namun, ada kalanya Aries juga memiliki sifat yang negatif yakni seperti terlalu pemikir, agak kasar, sombong, agresif, melakukan pekerjaan yang tidak diselesaikan dengan sempurna, hingga memiliki kelemahan. Di sini, zodiak Aries termasuk dalam kategori kardinal, atau yang dimaksud zodiak yang aktif."],
    ["Cancer", "Cancer merupakan salah satu zodiak yang memiliki sifat baik berupa keramahan, rasa simpati yang tinggi, pelindung yang baik, senang dengan kehidupan rumah tangga, memiliki rasa kesabaran yang besar, jujur, dan cerdas. Namun, Cancer juga memiliki sifat buruk, di antaranya adalah suka bersikap kekanak-kanakan, suka berpura-pura, terlalu memaksakan sesuatu, hingga tidak suka dengan hal-hal yang berbau perpisahan."],
    ["Taurus", "Taurus adalah zodiak yang akan dibahas selanjutnya. Sifat umum Taurus adalah sangat mengutamakan kekayaannya, sehingga ia pun gemar berpelesiran, memiliki rasa loyalitas yang tinggi, murah rezeki, hingga memiliki rasa ketabahan yang besar. Meski demikian, ada kalanya Taurus juga bersikap terlalu mengekang, keras hati, dan sering terjebak dalam pikiran yang buntu. Mungkin hal tersebut masuk dalam sifat buruk dari Taurus, sehingga zodiak ini termasuk dalam kategori tetap atau bisa juga stabil, dalam urusan ketabahan, daya tahan, hingga kesempurnaan."],
    ["Gemini", "Gemini condong memiliki sifat yang aktif, dimana ia sangat terampil dalam hal berkomunikasi, cerdas, multi talenta, senang bepergian, hingga mudah akrab dengan orang lain. Namun, jika dilihat dari sifat buruknya, Gemini juga kerap menjadi seseorang yang suka bersikap kekanak-kanakan, bermuka dua, gugup, berbicara omong kosong, suka berpura-pura, hingga bersikap hanya sekejap saja."],
    ["Leo", "Melambangkan singa, Leo bisa dibilang merupakan zodiak yang memiliki sifat yang amat menonjol dari 12 sifat zodiak lengkap. Seperti lambangnya, Leo sangat menggambarkan kemegahan, kepemimpinan, murah hati, penuh cinta, ramah, memiliki aura kagungan, keberanian, hingga berbakat dalam hal menghibur. Namun, dibalik itu, Leo ternyata juga memiliki beberapa sifat buruk. Mulai dari suka memperlihatkan kekuasaan, mengejar kemewahan, memiliki ego yang tinggi, banyak bicara, hingga suka pamer. Untuk kategori, Leo masuk kualifikasi tetap, di mana ia akan baik untuk memastikan sesuatu berjalan dengan lancar atau berhasil."],
    ["Virgo", "Zodiak yang mengutamakan kesehatan, Virgo juga sangat berkonsentrasi dan disiplin. Tidak hanya itu, Virgo juga suka bekerja, selalu ingin memberikan hasil kerja yang sempurna, praktis, siap melayani, hingga komperehensif. Namun, Virgo juga memiliki beberapa sifat buruk lho, yakni sering merasa khawatir yang berlebih, cerewet, suka mengkritik, berpandangan sempit, suka mengeluh, hingga tidak mudah mengaku kalah. Selain itu, Virgo juga termasuk dalam kategori zodiak yang variabel, di mana Virgo merupakan zodiak yang kreatif."],
    ["Libra", "Zodiak berlambang neraca ini ternyata memiliki sifat yang mengutamakan kesetaraan. Ciri khasnya, Libra dikenal seimbang, aliansi, diplomasi, suka membantu, selalu merasa ceria, sangat baik sebagai pasangan yang ideal, karena menyukai keadilan. Namun, ada kalanya sifat Libra sangat berbalik. Di mana Libra suka berpura-pura, tidak jujur, menyampaikan tujuan yang kurang tegas, atau tindakan kurang seimbang. Selain itu, Libra juga termasuk dalam kategori kardinal."],
    ["Scorpio", "Scorpio tentunya juga memiliki sifat yang sangat berciri khas. Zodiak yang melambangkan kalajengking ini disebut memiliki sifat yang sangat dekat kaitannya dengan kreativitas. Tidak hanya itu, Scorpio juga memiliki keinginan yang kuat, kemewahan, punya stamina serta daya sensual yang tinggi, hingga memiliki bakat menyembuhkan. Meski begitu, Scorpio juga ternyata mudah sekali cemburu, suka membinasakan diri, hingga fanatik. Untuk kategori, Scorpio masuk dalam kategori tetap, yakni termasuk zodiak yang stabilitas, ketabahan, ketahanan, dan kesempurnaan."],
    ["Sagitarius", "Di mana zodiak ini mengutamakan peminatan terhadap belajar. Selain itu, Sagitarius juga merupakan zodiak yang optimis, memiliki pemahaman diri yang baik, mempunyai cita-cita dan impian yang tinggi, bijaksana, senang bereksplorasi. Untuk sifat lainnya yang dinilai merupakan sifat buruk, di antaranya adalah Sagitarius termasuk pribadi yang lalai, tidak mematuhi hukum, memiliki kegelisahan yang besar, tidak jujur dan cenderung tidak bertanggung jawab. Sagitarius juga masuk dalam kategori variabel, karena mereka mudah mengalami daya perubahan, daya adaptasi dan daya keseimbangan."]
];
   //Watak
   var value;
   function prediksiZodiak(){
        //Mengambil data dari form bulan dan tanggal
       var zbulan = document.formzodiak.ibulanz.selectedIndex;
       var ztanggal = document.formzodiak.itanggalz.value;
       console.log(zbulan);
       console.log(ztanggal);
      if (zbulan == 12 && ztanggal >=22 || zbulan == 12 && ztanggal <=31) {
          value = "Capicorn";
      } 
      if (zbulan == 1 && ztanggal >=19) {
          value = "Capicorn";
      }  
      if (zbulan == 1 && ztanggal >=20 || zbulan == 2 && ztanggal <=18) {
          value = "Aquarius";
      } 
      if (zbulan == 2 && ztanggal >=19 || zbulan == 3 && ztanggal <=20) {
          value = "Pisces";
      }  
      if (zbulan == 2 && ztanggal > 29) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 3 && ztanggal >=21 || zbulan == 4 && ztanggal <=19) {
          value = "Aries";
      }  
      if (zbulan == 3 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 4 && ztanggal >=20 || zbulan == 5 && ztanggal <=20) {
          value = "Taurus";
      }  
      if (zbulan == 4 && ztanggal > 30) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 5 && ztanggal >=21 || zbulan == 6 && ztanggal <=21) {
          value = "Gemini";
      }  
      if (zbulan == 5 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 6 && ztanggal >=22 || zbulan == 7 && ztanggal <=22) {
          value = "Cancer";
      }  
      if (zbulan == 6 && ztanggal > 30) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 7 && ztanggal >=23 || zbulan == 8 && ztanggal <=22) {
          value = "Leo";
      }  
      if (zbulan == 7 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 8 && ztanggal >=23 || zbulan == 9 && ztanggal <=22) {
          value = "Virgo";
      }  
      if (zbulan == 8 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 9 && ztanggal >=23 || zbulan == 10 && ztanggal <=22) {
          value = "Libra";
      }  
      if (zbulan == 9 && ztanggal > 30) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 10 && ztanggal >=23 || zbulan == 11 && ztanggal <=21) {
          value = "Scorpio";
      }  
      if (zbulan == 10 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 11 && ztanggal >=22 || zbulan == 12 && ztanggal <=21) {
          value = "Sagitarius";
      }  
      if (zbulan == 11 && ztanggal > 30) {
          value = "Tanggal salah!!";
      }  
      if (zbulan == 12 && ztanggal >=22 || zbulan == 1 && ztanggal <=19) {
          value = "Capicorn";
      }  
      if (zbulan == 12 && ztanggal > 31) {
          value = "Tanggal salah!!";
      }
     console.log(value);
   }
  
  function hitungZodiak(){  
        //memanggil fungsi prediksiZodiak
        prediksiZodiak();
            //membuat perulangan mencari data di array dataweton
        for (var a = 0; a < datazodiak.length; a++) {
            if(value === datazodiak[a][0]){
            
            alert(value + " \n\n " + datazodiak[a][1]);
            
            }
        }
        if(value === "Tanggal salah!!"){
          
            alert('Tanggal tidak valid !');
        }
        
}
</script>


    <nav class="navbar navbar-expand-lg navbar-light"style="background:#696969;">
        <span class="navbar-brand"style="background:#696969;color:white;"></span>
    </nav>
    <br><br>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col justify-content-center">
                <br><center><img src="https://cdn.pixabay.com/photo/2021/03/27/06/31/code-6127616__340.png" alt="Logo" width="300" height="300"><br><br></center>
                <div class="alert alert-secondary" role="alert">
                        <center><span><i class="fa fa-terminal"></i> Tools dibuat oleh why.id<br>Seorang pengangguran yang suka pemrograman<br>&copy; GresiXploiter Team</span></center>
                    </button>
                </div>

                <div class="card">
                    <div class="card-body"style="background:#DCDCDC;">
                        <form action="" name="formzodiak" autocomplete="off">
                            <div class="form-group">
                                <label><i class="fa fa-plus-circle"></i> Tanggal</label>
                                <select name="itanggalz" class="form-control">  
                                    <option value="x">Pilih Tanggal</option>  
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>  
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>  
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>  
                                    <option value="10">10</option>
                                    <option value="11">11</option>  
                                    <option value="12">12</option>
                                    <option value="13">13</option>
                                    <option value="14">14</option>
                                    <option value="15">15</option>  
                                    <option value="16">16</option>
                                    <option value="17">17</option>
                                    <option value="18">18</option>  
                                    <option value="19">19</option>
                                    <option value="20">20</option>
                                    <option value="21">21</option>  
                                    <option value="22">22</option>
                                    <option value="23">23</option>
                                    <option value="24">24</option>
                                    <option value="25">25</option>  
                                    <option value="26">26</option>
                                    <option value="27">27</option>
                                    <option value="28">28</option>  
                                    <option value="29">29</option>
                                    <option value="30">30</option>
                                    <option value="31">31</option>
                              </select>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label><i class="fa fa-plus-circle"></i> Bulan</label>
                                <select name="ibulanz" class="form-control">  
                                    <option value="x">Pilih Bulan</option>  
                                    <option value="1">Januari</option>
                                    <option value="2">Februari</option>
                                    <option value="3">Maret</option>  
                                    <option value="4">April</option>
                                    <option value="5">Mei</option>
                                    <option value="6">Juni</option>  
                                    <option value="7">Juli</option>
                                    <option value="8">Agustus</option>
                                    <option value="9">September</option>  
                                    <option value="10">Oktober</option>
                                    <option value="11">November</option>  
                                    <option value="12">Desember</option>
                              </select>
                            </div>
                            <hr>
                            	<button onClick="hitungZodiak()" type="submit" name="submit" class="btn btn-dark btn-block"><i class="fa fa-check-square"></i> Lihat watak </button>
                        </form>
                    </div>
                    <div class="card-footer">
                        <small><i>Sumber : Primbon Jawa Kuno</i></small>
                    </div>
                </div>
            </div>
        </div>
</div>
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="sweetalert.min.js"></script>
</body>
</html>